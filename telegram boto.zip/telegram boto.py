import requests
import json
import time
from telegram.ext import Updater, CommandHandler
from datetime import datetime

TELEGRAM_TOKEN = '7019133967:AAElkXgrUvp9bNNqVO8mszrh7AmGA9yGkjI'

GIPHY_API_KEY = 'fJ74vboKTrTstQn2AzLzDFHJyQzqRxKs'

TELEGRAM_CHAT_ID = '1591612913'


project_views = {}


def fetch_views(project_id):
    try:
        url = f'https://api.giphy.com/v1/gifs/{project_id}?api_key={GIPHY_API_KEY}'
        response = requests.get(url)
        data = response.json()
        return data['data']['views']
    except Exception as e:
        print(f"Error fetching views for project {project_id}: {e}")
        return None


def start(update, context):
    update.message.reply_text('Welcome to the Giphy Views Tracker Bot!')


def track(update, context):
    if len(context.args) == 0:
        update.message.reply_text('Please provide a Giphy project ID.')
        return
    
    project_id = context.args[0]
    views = fetch_views(project_id)
    if views is not None:
        project_views[project_id] = views
        update.message.reply_text(f'Tracking views for project {project_id}.')
    else:
        update.message.reply_text(f'Failed to track views for project {project_id}.')


def send_daily_updates(context):
    for project_id, views in project_views.items():
        current_views = fetch_views(project_id)
        if current_views is not None:
            context.bot.send_message(chat_id=context.job.context, text=f'Daily views for project {project_id}: {current_views - views}')
            project_views[project_id] = current_views

def main():
    updater = Updater(TELEGRAM_TOKEN)
    dp = updater.dispatcher

    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(CommandHandler("track", track))

    job_queue = updater.job_queue
    job_queue.run_daily(send_daily_updates, time=datetime.now().time(), context=TELEGRAM_CHAT_ID)

    updater.start_polling()
    updater.idle()



if __name__ == '__main__':
    main()

